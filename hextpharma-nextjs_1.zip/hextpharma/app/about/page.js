import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'

export const metadata = {
  title: 'About Us',
  description: 'Learn about Hext Pharma Private Limited — our mission, values, and commitment to quality healthcare.',
}

const timeline = [
  { year: 'Vision', title: 'Founded with Purpose', desc: 'Hext Pharma was established with a clear mission: to make quality medicines accessible and affordable across India.' },
  { year: 'Products', title: 'Portfolio Built', desc: 'Developed a comprehensive range of 13+ products across 6 therapy areas, from antibiotics to nutraceuticals.' },
  { year: 'Reach', title: 'Pan-India Presence', desc: 'Expanded distribution network covering hospitals, clinics, and pharmacies across India with free bulk delivery.' },
  { year: 'Today', title: 'Trusted by 500+ Doctors', desc: 'Now a preferred pharmaceutical partner for physicians, gynaecologists, orthopaedists, paediatricians, surgeons, and ENT specialists.' },
]

const values = [
  { icon: '🎯', title: 'Quality First', desc: 'Every product undergoes rigorous quality checks before reaching patients. We never compromise on standards.' },
  { icon: '💙', title: 'Patient-Centric', desc: 'Our formulations are designed with patient safety, efficacy, and convenience as the top priorities.' },
  { icon: '🤝', title: 'Doctor Partnership', desc: 'We work closely with healthcare professionals to provide products that meet real clinical needs.' },
  { icon: '🌿', title: 'Innovation', desc: 'Continuously improving formulations and introducing new products to address evolving healthcare challenges.' },
  { icon: '🔒', title: 'Integrity', desc: 'Transparent business practices, honest pricing, and reliable supply chains you can depend on.' },
  { icon: '🚀', title: 'Accessibility', desc: 'Committed to making quality medicines affordable and available in every corner of India.' },
]

const team = [
  { name: 'Er. Rishabh', role: 'Director', initial: 'R', sub: 'S/o Late B.K. Singh' },
]

export default function AboutPage() {
  return (
    <>
      <Navbar />
      <main className="pt-16">

        {/* Hero */}
        <section className="hero-bg py-20 relative overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <div className="badge bg-brand-100 text-brand-600 mb-5">About Us</div>
                <h1 className="text-4xl md:text-5xl font-bold font-display text-brand-900 mb-5 leading-tight">
                  Healing Lives with<br />
                  <span className="text-brand-500">Quality Medicines</span>
                </h1>
                <p className="text-slate-600 text-lg leading-relaxed mb-6">
                  Hext Pharma Private Limited is a Delhi-based pharmaceutical company dedicated to manufacturing 
                  and distributing high-quality medicines for healthcare professionals and patients across India.
                </p>
                <div className="flex flex-wrap gap-4">
                  {[
                    { label: '13+', sub: 'Products' },
                    { label: '6', sub: 'Therapy Areas' },
                    { label: '6', sub: 'Specialties' },
                    { label: 'PAN', sub: 'India Reach' },
                  ].map(stat => (
                    <div key={stat.sub} className="bg-white rounded-2xl px-5 py-3 shadow-sm border border-slate-100 text-center min-w-[80px]">
                      <div className="text-2xl font-bold font-display text-brand-600">{stat.label}</div>
                      <div className="text-xs text-slate-400">{stat.sub}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="hidden lg:block">
                <div className="relative">
                  <div className="absolute inset-0 bg-brand-100 rounded-3xl transform rotate-3" />
                  <div className="relative bg-white rounded-3xl p-8 shadow-xl">
                    <h3 className="font-bold font-display text-brand-800 text-xl mb-4">Our Mission</h3>
                    <p className="text-slate-500 leading-relaxed mb-5">
                      To manufacture and distribute pharmaceutical products of the highest quality, 
                      ensuring every patient receives safe, effective, and affordable treatment — wherever they are in India.
                    </p>
                    <h3 className="font-bold font-display text-brand-800 text-xl mb-4">Our Vision</h3>
                    <p className="text-slate-500 leading-relaxed">
                      To become India's most trusted pharmaceutical brand — known for quality, integrity, 
                      and a relentless commitment to improving patient outcomes across every medical specialty.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="absolute bottom-0 left-0 right-0 pointer-events-none">
            <svg viewBox="0 0 1440 40" fill="none" className="w-full">
              <path d="M0 40L1440 0V40H0Z" fill="white" />
            </svg>
          </div>
        </section>

        {/* Company Info */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 items-start">
              <div>
                <div className="badge bg-blue-50 text-blue-700 mb-5">Company Details</div>
                <h2 className="section-title mb-6">Hext Pharma Private Limited</h2>
                <div className="space-y-4 text-slate-600">
                  <div className="flex gap-4 p-4 rounded-2xl bg-soft border border-slate-100">
                    <span className="text-2xl flex-shrink-0">🏢</span>
                    <div>
                      <div className="font-semibold text-brand-800 mb-1">Registered Address</div>
                      <p className="text-sm leading-relaxed">27/109/3a, Opp Shankar Gali Main Panday Road, Jwala Nagar, Shahdara, Delhi North East, Delhi – 110032</p>
                    </div>
                  </div>
                  <div className="flex gap-4 p-4 rounded-2xl bg-soft border border-slate-100">
                    <span className="text-2xl flex-shrink-0">📞</span>
                    <div>
                      <div className="font-semibold text-brand-800 mb-1">Contact Numbers</div>
                      <p className="text-sm">9065395864 &nbsp;|&nbsp; 9534891576</p>
                    </div>
                  </div>
                  <div className="flex gap-4 p-4 rounded-2xl bg-soft border border-slate-100">
                    <span className="text-2xl flex-shrink-0">📧</span>
                    <div>
                      <div className="font-semibold text-brand-800 mb-1">Email</div>
                      <a href="mailto:hextpharma73@gmail.com" className="text-sm text-brand-500 hover:underline">hextpharma73@gmail.com</a>
                    </div>
                  </div>
                  <div className="flex gap-4 p-4 rounded-2xl bg-soft border border-slate-100">
                    <span className="text-2xl flex-shrink-0">🌐</span>
                    <div>
                      <div className="font-semibold text-brand-800 mb-1">Website</div>
                      <p className="text-sm">www.hextpharma.com</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Journey */}
              <div>
                <div className="badge bg-green-50 text-green-700 mb-5">Our Journey</div>
                <h2 className="section-title mb-6">How We Got Here</h2>
                <div className="relative">
                  <div className="absolute left-5 top-0 bottom-0 w-0.5 bg-brand-100" />
                  <div className="space-y-8">
                    {timeline.map((item, i) => (
                      <div key={i} className="flex gap-6 relative">
                        <div className="w-10 h-10 rounded-full bg-brand-500 flex items-center justify-center flex-shrink-0 z-10 shadow-md">
                          <span className="text-white font-bold font-display text-xs">{i + 1}</span>
                        </div>
                        <div className="pt-1.5">
                          <div className="badge bg-brand-50 text-brand-600 text-xs mb-2">{item.year}</div>
                          <h4 className="font-bold text-brand-800 font-display mb-1">{item.title}</h4>
                          <p className="text-sm text-slate-500 leading-relaxed">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Values */}
        <section className="py-20 bg-soft grid-pattern">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-14">
              <div className="badge bg-purple-50 text-purple-600 mb-4">What We Stand For</div>
              <h2 className="section-title mb-4">Our Core Values</h2>
              <p className="section-sub text-center">The principles that guide every decision we make.</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {values.map((v, i) => (
                <div key={i} className="card p-6 text-center group hover:-translate-y-1 transition-all duration-200">
                  <div className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-200">{v.icon}</div>
                  <h3 className="font-bold text-brand-800 font-display text-base mb-2">{v.title}</h3>
                  <p className="text-sm text-slate-500 leading-relaxed">{v.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Leadership */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-14">
              <div className="badge bg-brand-50 text-brand-600 mb-4">Leadership</div>
              <h2 className="section-title mb-4">Meet Our Team</h2>
            </div>
            <div className="flex justify-center">
              {team.map((member, i) => (
                <div key={i} className="card p-8 text-center max-w-xs w-full">
                  <div className="w-20 h-20 rounded-full bg-brand-500 flex items-center justify-center mx-auto mb-4 shadow-lg">
                    <span className="text-white font-bold font-display text-2xl">{member.initial}</span>
                  </div>
                  <h3 className="font-bold text-brand-800 font-display text-xl mb-1">{member.name}</h3>
                  <div className="badge bg-brand-50 text-brand-600 mb-2">{member.role}</div>
                  <p className="text-sm text-slate-400">{member.sub}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

      </main>
      <Footer />
    </>
  )
}
