export const metadata = {
  title: 'Products',
  description: 'Browse Hext Pharma\'s full pharmaceutical product range — antibiotics, gastro care, pain relief, nutraceuticals, haematinics and more.',
}

export { default } from './page'
