'use client'
import { useState } from 'react'
import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'
import { products, categories, doctorGroups } from '../../data/products'

const categoryColors = {
  'Antibiotic':    'bg-red-50 text-red-600 border-red-100',
  'Gastro':        'bg-yellow-50 text-yellow-700 border-yellow-100',
  'Digestive':     'bg-green-50 text-green-700 border-green-100',
  'Pain Relief':   'bg-orange-50 text-orange-700 border-orange-100',
  'Nutraceutical': 'bg-purple-50 text-purple-700 border-purple-100',
  'Haematinics':   'bg-rose-50 text-rose-700 border-rose-100',
}

export default function ProductsPage() {
  const [activeCategory, setActiveCategory] = useState('All')
  const [activeDoctor, setActiveDoctor]     = useState('All')
  const [search, setSearch]                 = useState('')

  const doctorNames = ['All', ...doctorGroups.map(d => d.group)]

  const filtered = products.filter(p => {
    const matchCat  = activeCategory === 'All' || p.category === activeCategory
    const matchDoc  = activeDoctor   === 'All' || p.doctorGroup.includes(activeDoctor)
    const matchSrch = p.name.toLowerCase().includes(search.toLowerCase()) ||
                      p.composition.toLowerCase().includes(search.toLowerCase())
    return matchCat && matchDoc && matchSrch
  })

  return (
    <>
      <Navbar />
      <main className="pt-16">
        {/* Hero banner */}
        <section className="hero-bg py-16 relative overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="badge bg-brand-100 text-brand-600 mb-4">Our Portfolio</div>
            <h1 className="text-4xl md:text-5xl font-bold font-display text-brand-900 mb-4">
              Pharmaceutical Products
            </h1>
            <p className="text-slate-500 text-lg max-w-xl mx-auto">
              13 carefully formulated products across 6 therapy areas — trusted by doctors and patients across India.
            </p>
          </div>
          <div className="absolute bottom-0 left-0 right-0 pointer-events-none">
            <svg viewBox="0 0 1440 40" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full">
              <path d="M0 40L1440 0V40H0Z" fill="white"/>
            </svg>
          </div>
        </section>

        <section className="py-14 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

            {/* Search & Filters */}
            <div className="mb-10 space-y-5">
              {/* Search */}
              <div className="relative max-w-md">
                <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                <input
                  type="text"
                  placeholder="Search by name or composition…"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-brand-400 focus:ring-2 focus:ring-brand-100 transition-all"
                />
              </div>

              {/* Category filter */}
              <div>
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-3">By Category</p>
                <div className="flex flex-wrap gap-2">
                  {categories.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setActiveCategory(cat)}
                      className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-150 border ${
                        activeCategory === cat
                          ? 'bg-brand-500 text-white border-brand-500 shadow-sm'
                          : 'bg-white text-slate-600 border-slate-200 hover:border-brand-300 hover:text-brand-600'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Doctor filter */}
              <div>
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-3">By Doctor Specialty</p>
                <div className="flex flex-wrap gap-2">
                  {doctorNames.map(doc => (
                    <button
                      key={doc}
                      onClick={() => setActiveDoctor(doc)}
                      className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-150 border ${
                        activeDoctor === doc
                          ? 'bg-brand-700 text-white border-brand-700 shadow-sm'
                          : 'bg-white text-slate-600 border-slate-200 hover:border-brand-300 hover:text-brand-600'
                      }`}
                    >
                      {doc}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Results count */}
            <p className="text-sm text-slate-400 mb-6">
              Showing <span className="font-semibold text-brand-700">{filtered.length}</span> product{filtered.length !== 1 ? 's' : ''}
            </p>

            {/* Products grid */}
            {filtered.length === 0 ? (
              <div className="text-center py-20 text-slate-400">
                <div className="text-5xl mb-4">💊</div>
                <p className="text-lg font-medium">No products found</p>
                <p className="text-sm mt-1">Try adjusting your filters or search term.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filtered.map(product => (
                  <div key={product.id} id={String(product.id)} className="card p-6 hover:-translate-y-1 transition-all duration-200 group">
                    <div className="flex items-start justify-between mb-4">
                      <span className={`badge border text-xs ${categoryColors[product.category] || 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                        {product.category}
                      </span>
                      <span className={`badge text-xs ${product.badge === 'Rx' ? 'bg-brand-50 text-brand-700' : 'bg-green-50 text-green-700'}`}>
                        {product.badge}
                      </span>
                    </div>

                    <h3 className="font-bold text-brand-800 font-display text-base mb-1 group-hover:text-brand-600 transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-xs text-slate-400 mb-3 leading-relaxed">{product.composition}</p>
                    <p className="text-sm text-slate-500 mb-4 leading-relaxed">{product.description}</p>

                    {/* Doctor groups */}
                    <div className="flex flex-wrap gap-1.5 mb-4">
                      {product.doctorGroup.map(doc => (
                        <span key={doc} className="text-[10px] bg-slate-50 text-slate-500 border border-slate-100 px-2 py-0.5 rounded-full">
                          {doc}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                      <div>
                        <div className="text-xs text-slate-400">MRP (Incl. all taxes)</div>
                        <div className="font-bold text-brand-700 font-display text-xl">₹{product.mrp.toFixed(2)}</div>
                      </div>
                      <a
                        href={`/contact?product=${encodeURIComponent(product.name)}`}
                        className="text-xs font-semibold bg-brand-50 text-brand-600 hover:bg-brand-500 hover:text-white px-3 py-2 rounded-lg transition-all duration-150"
                      >
                        Enquire
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
