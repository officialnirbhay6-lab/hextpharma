import '../styles/globals.css'

export const metadata = {
  metadataBase: new URL('https://hextpharma.com'),
  title: {
    default: 'Hext Pharma | Quality Medicines You Can Trust',
    template: '%s | Hext Pharma',
  },
  description: 'Hext Pharma Private Limited — manufacturer & distributor of high-quality pharmaceutical products. Free delivery across India on orders above ₹5,000.',
  keywords: ['pharma', 'medicines', 'hext pharma', 'pharmaceutical', 'bulk order', 'azithromycin', 'vitamins', 'Delhi'],
  openGraph: {
    type: 'website',
    locale: 'en_IN',
    url: 'https://hextpharma.com',
    siteName: 'Hext Pharma',
    title: 'Hext Pharma | Quality Medicines You Can Trust',
    description: 'Premium pharmaceutical products. Free delivery all over India on bulk orders above ₹5,000.',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Hext Pharma',
    description: 'Premium pharmaceutical products. Free delivery all over India on bulk orders above ₹5,000.',
  },
  robots: { index: true, follow: true },
  alternates: { canonical: 'https://hextpharma.com' },
}

export default function RootLayout({ children }) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,400&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="antialiased">{children}</body>
    </html>
  )
}
