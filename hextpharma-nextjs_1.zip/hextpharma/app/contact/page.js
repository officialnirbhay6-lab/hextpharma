'use client'
import { useState } from 'react'
import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'

export default function ContactPage() {
  const [form, setForm]       = useState({ name: '', email: '', phone: '', subject: '', message: '' })
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleChange = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }))

  const handleSubmit = async e => {
    e.preventDefault()
    setLoading(true)
    await new Promise(r => setTimeout(r, 1000))
    setLoading(false)
    setSubmitted(true)
  }

  return (
    <>
      <Navbar />
      <main className="pt-16">

        {/* Hero */}
        <section className="hero-bg py-16 relative overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="badge bg-brand-100 text-brand-600 mb-4">Get In Touch</div>
            <h1 className="text-4xl md:text-5xl font-bold font-display text-brand-900 mb-4">Contact Us</h1>
            <p className="text-slate-500 text-lg max-w-xl mx-auto">
              Have a query about our products, bulk orders, or partnerships? We're here to help.
            </p>
          </div>
          <div className="absolute bottom-0 left-0 right-0 pointer-events-none">
            <svg viewBox="0 0 1440 40" fill="none" className="w-full">
              <path d="M0 40L1440 0V40H0Z" fill="white" />
            </svg>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-5 gap-12">

              {/* Contact Info */}
              <div className="lg:col-span-2 space-y-6">
                <div>
                  <h2 className="text-2xl font-bold font-display text-brand-800 mb-2">We'd Love to Hear From You</h2>
                  <p className="text-slate-500 text-sm leading-relaxed">
                    Reach out for product enquiries, bulk order pricing, distribution partnerships, or any other questions.
                  </p>
                </div>

                {[
                  {
                    icon: '📍',
                    title: 'Our Office',
                    lines: ['27/109/3a, Opp Shankar Gali Main Panday Road', 'Jwala Nagar, Shahdara, Delhi North East', 'Delhi – 110032'],
                  },
                  {
                    icon: '📞',
                    title: 'Phone Numbers',
                    lines: ['9065395864', '9534891576'],
                    href: ['tel:9065395864', 'tel:9534891576'],
                  },
                  {
                    icon: '📧',
                    title: 'Email Address',
                    lines: ['hextpharma73@gmail.com'],
                    href: ['mailto:hextpharma73@gmail.com'],
                  },
                  {
                    icon: '⏰',
                    title: 'Business Hours',
                    lines: ['Mon–Sat: 9:00 AM – 6:00 PM', 'Sunday: Closed'],
                  },
                ].map((item, i) => (
                  <div key={i} className="flex gap-4 p-5 rounded-2xl bg-soft border border-slate-100">
                    <div className="text-2xl flex-shrink-0">{item.icon}</div>
                    <div>
                      <div className="font-semibold text-brand-800 text-sm mb-1">{item.title}</div>
                      {item.lines.map((line, j) => (
                        item.href?.[j]
                          ? <a key={j} href={item.href[j]} className="block text-sm text-brand-500 hover:text-brand-700 transition-colors">{line}</a>
                          : <p key={j} className="text-sm text-slate-500">{line}</p>
                      ))}
                    </div>
                  </div>
                ))}

                {/* Free delivery callout */}
                <div className="p-5 rounded-2xl bg-brand-700 text-white">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xl">🚚</span>
                    <span className="font-bold font-display text-sm">Free Delivery Offer</span>
                  </div>
                  <p className="text-brand-200 text-xs leading-relaxed">
                    All bulk orders above ₹5,000 get <strong className="text-white">FREE delivery</strong> anywhere in India. 
                    Contact us to know more about our bulk pricing.
                  </p>
                </div>
              </div>

              {/* Form */}
              <div className="lg:col-span-3">
                <div className="card p-8">
                  {submitted ? (
                    <div className="text-center py-10">
                      <div className="text-5xl mb-4">✅</div>
                      <h3 className="text-xl font-bold font-display text-brand-800 mb-2">Message Sent!</h3>
                      <p className="text-slate-500 text-sm mb-6">
                        Thank you for reaching out. Our team will get back to you within 24 hours.
                      </p>
                      <button
                        onClick={() => { setSubmitted(false); setForm({ name:'', email:'', phone:'', subject:'', message:'' }) }}
                        className="btn-outline"
                      >
                        Send Another Message
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-5">
                      <h3 className="text-xl font-bold font-display text-brand-800 mb-2">Send Us a Message</h3>

                      <div className="grid sm:grid-cols-2 gap-5">
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1.5">Full Name *</label>
                          <input
                            type="text" name="name" required value={form.name} onChange={handleChange}
                            placeholder="Dr. Ramesh Kumar"
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-brand-400 focus:ring-2 focus:ring-brand-100 transition-all"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1.5">Phone Number *</label>
                          <input
                            type="tel" name="phone" required value={form.phone} onChange={handleChange}
                            placeholder="+91 98765 43210"
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-brand-400 focus:ring-2 focus:ring-brand-100 transition-all"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1.5">Email Address</label>
                        <input
                          type="email" name="email" value={form.email} onChange={handleChange}
                          placeholder="doctor@hospital.com"
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-brand-400 focus:ring-2 focus:ring-brand-100 transition-all"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1.5">Subject *</label>
                        <select
                          name="subject" required value={form.subject} onChange={handleChange}
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-brand-400 focus:ring-2 focus:ring-brand-100 transition-all bg-white"
                        >
                          <option value="">Select a subject…</option>
                          <option value="product-enquiry">Product Enquiry</option>
                          <option value="bulk-order">Bulk Order / Pricing</option>
                          <option value="distribution">Distribution Partnership</option>
                          <option value="complaint">Complaint / Feedback</option>
                          <option value="other">Other</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1.5">Message *</label>
                        <textarea
                          name="message" required rows={5} value={form.message} onChange={handleChange}
                          placeholder="Tell us how we can help you…"
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-brand-400 focus:ring-2 focus:ring-brand-100 transition-all resize-none"
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={loading}
                        className="w-full btn-primary justify-center py-3.5 disabled:opacity-60 disabled:cursor-not-allowed"
                      >
                        {loading ? (
                          <>
                            <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"/>
                            </svg>
                            Sending…
                          </>
                        ) : (
                          <>
                            Send Message
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                            </svg>
                          </>
                        )}
                      </button>
                    </form>
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>

      </main>
      <Footer />
    </>
  )
}
